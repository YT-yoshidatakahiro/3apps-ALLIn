﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vb_mainpage
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_toDentaku = New System.Windows.Forms.Button()
        Me.btn_toCsvpage = New System.Windows.Forms.Button()
        Me.btn_mainclose = New System.Windows.Forms.Button()
        Me.btn_AccsDb = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_toDentaku
        '
        Me.btn_toDentaku.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_toDentaku.Location = New System.Drawing.Point(12, 12)
        Me.btn_toDentaku.Name = "btn_toDentaku"
        Me.btn_toDentaku.Size = New System.Drawing.Size(168, 77)
        Me.btn_toDentaku.TabIndex = 0
        Me.btn_toDentaku.Text = "電卓画面"
        Me.btn_toDentaku.UseVisualStyleBackColor = True
        '
        'btn_toCsvpage
        '
        Me.btn_toCsvpage.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_toCsvpage.Location = New System.Drawing.Point(186, 12)
        Me.btn_toCsvpage.Name = "btn_toCsvpage"
        Me.btn_toCsvpage.Size = New System.Drawing.Size(285, 77)
        Me.btn_toCsvpage.TabIndex = 1
        Me.btn_toCsvpage.Text = "CSVファイル読み書き画面"
        Me.btn_toCsvpage.UseVisualStyleBackColor = True
        '
        'btn_mainclose
        '
        Me.btn_mainclose.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_mainclose.Location = New System.Drawing.Point(651, 12)
        Me.btn_mainclose.Name = "btn_mainclose"
        Me.btn_mainclose.Size = New System.Drawing.Size(168, 77)
        Me.btn_mainclose.TabIndex = 2
        Me.btn_mainclose.Text = "閉じる"
        Me.btn_mainclose.UseVisualStyleBackColor = True
        '
        'btn_AccsDb
        '
        Me.btn_AccsDb.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_AccsDb.Location = New System.Drawing.Point(477, 12)
        Me.btn_AccsDb.Name = "btn_AccsDb"
        Me.btn_AccsDb.Size = New System.Drawing.Size(168, 77)
        Me.btn_AccsDb.TabIndex = 0
        Me.btn_AccsDb.Text = "AccsDB登録"
        Me.btn_AccsDb.UseVisualStyleBackColor = True
        '
        'vb_mainpage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(836, 107)
        Me.Controls.Add(Me.btn_toCsvpage)
        Me.Controls.Add(Me.btn_AccsDb)
        Me.Controls.Add(Me.btn_mainclose)
        Me.Controls.Add(Me.btn_toDentaku)
        Me.Name = "vb_mainpage"
        Me.Text = "メイン画面"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btn_toDentaku As Button
    Friend WithEvents btn_toCsvpage As Button
    Friend WithEvents btn_mainclose As Button
    Friend WithEvents btn_AccsDb As Button
End Class
