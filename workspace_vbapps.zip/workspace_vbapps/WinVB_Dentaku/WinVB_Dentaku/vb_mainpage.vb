﻿Public Class vb_mainpage
    '電卓画面開く
    Private Sub btn_toDentaku_Click(sender As Object, e As EventArgs) Handles btn_toDentaku.Click
        frm_Dentaku.Left = 100
        frm_Dentaku.Top = 200
        frm_Dentaku.StartPosition = FormStartPosition.Manual
        frm_Dentaku.ShowDialog()

    End Sub

    'CSVファイル読み書き画面を開く
    Private Sub btn_toCsvpage_Click(sender As Object, e As EventArgs) Handles btn_toCsvpage.Click
        vb_CSVinout.Left = 100
        vb_CSVinout.Top = 200
        vb_CSVinout.StartPosition = FormStartPosition.Manual
        vb_CSVinout.ShowDialog()

    End Sub

    Private Sub btn_AccsDb_Click(sender As Object, e As EventArgs) Handles btn_AccsDb.Click
        frm_accsDB.Left = 100
        frm_accsDB.Top = 200
        frm_accsDB.StartPosition = FormStartPosition.Manual
        frm_accsDB.ShowDialog()

    End Sub

    'メイン画面を閉じる
    Private Sub btn_mainclose_Click(sender As Object, e As EventArgs) Handles btn_mainclose.Click

        Me.Close()

    End Sub

    'メイン画面初期表示設定
    Private Sub vb_mainpage_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.ControlBox = Not Me.ControlBox

        Me.Left = 100

        Me.Top = 200

        Me.StartPosition = FormStartPosition.Manual

    End Sub
End Class