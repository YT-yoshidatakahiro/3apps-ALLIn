﻿Public Class vb_CSVinout

    Dim csv_dialog As New OpenFileDialog()

    Dim csv_save_dialog As New SaveFileDialog()

    Dim vb_dat_path As String = "D:\workspace_vbapps\vb_datfile"

    Dim chk As String = "check"


    'アプリ閉じる
    Private Sub btn_csvclose_Click(sender As Object, e As EventArgs) Handles btn_csvclose.Click

        'グリッドビュー初期化
        grid_init_func()

        dgv_csvdat.Rows.Clear()

        Me.Close()

    End Sub

    '行追加
    Private Sub btn_rowadd_Click(sender As Object, e As EventArgs) Handles btn_rowadd.Click

        dgv_csvdat.Rows.Add()

    End Sub

    '表全行削除
    Private Sub btn_alldel_Click(sender As Object, e As EventArgs) Handles btn_alldel.Click

        dgv_csvdat.Rows.Clear()

    End Sub

    '選択行削除
    Private Sub btn_selectde_Click(sender As Object, e As EventArgs) Handles btn_selectdel.Click

        Dim i As Integer

        For i = dgv_csvdat.Rows.Count - 2 To 0 Step -1

            If dgv_csvdat.Rows(i).Cells(0).Value = True Then

                dgv_csvdat.Rows.RemoveAt(i)

            End If
        Next i
    End Sub

    '現在行削除
    Private Sub btn_selecteddel_Click(sender As Object, e As EventArgs) Handles btn_selecteddel.Click

        '参考文
        ' If dgv_csvdat.Rows.Count > 1 Then
        '
        '     For Each row As DataGridViewRow In Me.dgv_csvdat.SelectedRows
        '
        '         Me.dgv_csvdat.Rows.Remove(row)
        '
        '     Next
        '
        ' End If
        If dgv_csvdat.Rows.Count > 1 And dgv_csvdat.CurrentCell.RowIndex < dgv_csvdat.Rows.Count - 1 Then

            Me.dgv_csvdat.Rows.RemoveAt(Me.dgv_csvdat.CurrentCell.RowIndex)

        End If
    End Sub

    'csvファイル読込
    'ファイルは，txtファイルかcsvファイルのみ
    Private Sub btn_csvread_Click(sender As Object, e As EventArgs) Handles btn_csvread.Click

        Dim rc As Integer

        If dgv_csvdat.Rows.Count > 1 Then

            rc = MsgBox("保存しますか", vbYesNo)

            If rc = vbYes Then

                dgv_csvdat.Rows.Clear()

                csv_dialog.InitialDirectory = vb_dat_path

                csv_save_dialog.ShowDialog()

            End If
        End If

        grid_init_func()

        csv_dialog.InitialDirectory = vb_dat_path

        If csv_dialog.ShowDialog() = DialogResult.OK Then

            If Not csv_dialog.FileName.Contains(".csv") Or csv_dialog.FileName.Contains(".txt") Then

                MsgBox("読込可能なファイルはcsvファイルかtxtファイルのみです")

            Else
                '処理実行
                Dim csv_read As New FileIO.TextFieldParser(csv_dialog.FileName, System.Text.Encoding.GetEncoding("utf-8"))

                csv_read.TextFieldType = FileIO.FieldType.Delimited

                csv_read.SetDelimiters(",")

                csv_read.ReadFields()

                While Not csv_read.EndOfData

                    dgv_csvdat.Rows.Add(csv_read.ReadFields())

                End While

                'チェックボックス追加
                dgv_csvdat.Columns.Insert(0, New DataGridViewCheckBoxColumn)

                dgv_csvdat.Columns(0).HeaderText = chk
            End If
        End If
    End Sub


    'csvファイル掃き出し
    Private Sub btn_csvwrite_Click(sender As Object, e As EventArgs) Handles btn_csvwrite.Click

        Dim str_write As String

        Dim csv_write As IO.TextWriter

        csv_dialog.InitialDirectory = vb_dat_path

        'グリッドビューが2行以上あるとき書込み
        If dgv_csvdat.Rows.Count > 1 Then

            If csv_dialog.ShowDialog() = DialogResult.OK Then

                csv_write = New IO.StreamWriter(csv_dialog.FileName, False, System.Text.Encoding.GetEncoding("utf-8"))

                For i = 0 To dgv_csvdat.Rows.Count - 2

                    For j = 1 To dgv_csvdat.Columns.Count - 1

                        str_write = str_write + dgv_csvdat.Rows(i).Cells(j).Value + ","

                    Next j

                    '最終行処理
                    If i = dgv_csvdat.Rows.Count - 2 Then

                        str_write = str_write.TrimEnd(CType(",", Char))

                    Else
                        str_write = str_write + vbNewLine

                    End If
                Next i

                csv_write.Write(str_write)
            End If

            csv_write.Close()

            MsgBox("書込み完了")

        End If
    End Sub

    Private Sub dgv_csvdat_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_csvdat.CellContentClick

    End Sub
    'CSVアプリ起動初期時
    Private Sub vb_CSVinout_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.ControlBox = Not Me.ControlBox

    End Sub


    'グリッドビュー初期化関数
    Private Sub grid_init_func()

        If dgv_csvdat.Columns(0).HeaderText = chk Then

            dgv_csvdat.Columns.RemoveAt(0)

        End If

    End Sub
End Class