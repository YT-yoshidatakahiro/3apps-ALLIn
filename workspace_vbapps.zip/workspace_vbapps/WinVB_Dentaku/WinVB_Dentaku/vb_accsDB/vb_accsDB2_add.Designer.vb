﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vb_accsDB2_add
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_accsDB_add = New System.Windows.Forms.Button()
        Me.btn_add_close = New System.Windows.Forms.Button()
        Me.cmb_accss_sex_add = New System.Windows.Forms.ComboBox()
        Me.tb_accs_name_add = New System.Windows.Forms.TextBox()
        Me.lb_accs_name_add = New System.Windows.Forms.Label()
        Me.lb_accs_sex_add = New System.Windows.Forms.Label()
        Me.lb_job_add = New System.Windows.Forms.Label()
        Me.lb_accs_id1_add = New System.Windows.Forms.Label()
        Me.lb_accs_id2_add = New System.Windows.Forms.Label()
        Me.cmb_accss_job_add = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'btn_accsDB_add
        '
        Me.btn_accsDB_add.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_accsDB_add.Location = New System.Drawing.Point(74, 12)
        Me.btn_accsDB_add.Name = "btn_accsDB_add"
        Me.btn_accsDB_add.Size = New System.Drawing.Size(78, 60)
        Me.btn_accsDB_add.TabIndex = 0
        Me.btn_accsDB_add.Text = "登録"
        Me.btn_accsDB_add.UseVisualStyleBackColor = True
        '
        'btn_add_close
        '
        Me.btn_add_close.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_add_close.Location = New System.Drawing.Point(158, 12)
        Me.btn_add_close.Name = "btn_add_close"
        Me.btn_add_close.Size = New System.Drawing.Size(78, 60)
        Me.btn_add_close.TabIndex = 0
        Me.btn_add_close.Text = "閉じる"
        Me.btn_add_close.UseVisualStyleBackColor = True
        '
        'cmb_accss_sex_add
        '
        Me.cmb_accss_sex_add.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.cmb_accss_sex_add.FormattingEnabled = True
        Me.cmb_accss_sex_add.Location = New System.Drawing.Point(74, 160)
        Me.cmb_accss_sex_add.Name = "cmb_accss_sex_add"
        Me.cmb_accss_sex_add.Size = New System.Drawing.Size(162, 32)
        Me.cmb_accss_sex_add.TabIndex = 1
        '
        'tb_accs_name_add
        '
        Me.tb_accs_name_add.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.tb_accs_name_add.Location = New System.Drawing.Point(74, 123)
        Me.tb_accs_name_add.Name = "tb_accs_name_add"
        Me.tb_accs_name_add.Size = New System.Drawing.Size(162, 31)
        Me.tb_accs_name_add.TabIndex = 2
        '
        'lb_accs_name_add
        '
        Me.lb_accs_name_add.AutoSize = True
        Me.lb_accs_name_add.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.lb_accs_name_add.Location = New System.Drawing.Point(10, 126)
        Me.lb_accs_name_add.Name = "lb_accs_name_add"
        Me.lb_accs_name_add.Size = New System.Drawing.Size(58, 24)
        Me.lb_accs_name_add.TabIndex = 3
        Me.lb_accs_name_add.Text = "名前"
        '
        'lb_accs_sex_add
        '
        Me.lb_accs_sex_add.AutoSize = True
        Me.lb_accs_sex_add.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.lb_accs_sex_add.Location = New System.Drawing.Point(10, 163)
        Me.lb_accs_sex_add.Name = "lb_accs_sex_add"
        Me.lb_accs_sex_add.Size = New System.Drawing.Size(58, 24)
        Me.lb_accs_sex_add.TabIndex = 3
        Me.lb_accs_sex_add.Text = "性別"
        '
        'lb_job_add
        '
        Me.lb_job_add.AutoSize = True
        Me.lb_job_add.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.lb_job_add.Location = New System.Drawing.Point(10, 201)
        Me.lb_job_add.Name = "lb_job_add"
        Me.lb_job_add.Size = New System.Drawing.Size(58, 24)
        Me.lb_job_add.TabIndex = 3
        Me.lb_job_add.Text = "職業"
        '
        'lb_accs_id1_add
        '
        Me.lb_accs_id1_add.AutoSize = True
        Me.lb_accs_id1_add.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.lb_accs_id1_add.Location = New System.Drawing.Point(41, 93)
        Me.lb_accs_id1_add.Name = "lb_accs_id1_add"
        Me.lb_accs_id1_add.Size = New System.Drawing.Size(27, 24)
        Me.lb_accs_id1_add.TabIndex = 3
        Me.lb_accs_id1_add.Text = "id"
        '
        'lb_accs_id2_add
        '
        Me.lb_accs_id2_add.AutoSize = True
        Me.lb_accs_id2_add.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.lb_accs_id2_add.Location = New System.Drawing.Point(74, 93)
        Me.lb_accs_id2_add.Name = "lb_accs_id2_add"
        Me.lb_accs_id2_add.Size = New System.Drawing.Size(154, 24)
        Me.lb_accs_id2_add.TabIndex = 3
        Me.lb_accs_id2_add.Text = "　　　　　　　　　"
        '
        'cmb_accss_job_add
        '
        Me.cmb_accss_job_add.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.cmb_accss_job_add.FormattingEnabled = True
        Me.cmb_accss_job_add.Location = New System.Drawing.Point(74, 201)
        Me.cmb_accss_job_add.Name = "cmb_accss_job_add"
        Me.cmb_accss_job_add.Size = New System.Drawing.Size(162, 32)
        Me.cmb_accss_job_add.TabIndex = 1
        '
        'vb_accsDB2_add
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(256, 243)
        Me.Controls.Add(Me.lb_job_add)
        Me.Controls.Add(Me.lb_accs_sex_add)
        Me.Controls.Add(Me.lb_accs_id2_add)
        Me.Controls.Add(Me.lb_accs_id1_add)
        Me.Controls.Add(Me.lb_accs_name_add)
        Me.Controls.Add(Me.tb_accs_name_add)
        Me.Controls.Add(Me.cmb_accss_job_add)
        Me.Controls.Add(Me.cmb_accss_sex_add)
        Me.Controls.Add(Me.btn_add_close)
        Me.Controls.Add(Me.btn_accsDB_add)
        Me.Name = "vb_accsDB2_add"
        Me.Text = "accs追加画面"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_accsDB_add As Button
    Friend WithEvents btn_add_close As Button
    Friend WithEvents cmb_accss_sex_add As ComboBox
    Friend WithEvents tb_accs_name_add As TextBox
    Friend WithEvents lb_accs_name_add As Label
    Friend WithEvents lb_accs_sex_add As Label
    Friend WithEvents lb_job_add As Label
    Friend WithEvents lb_accs_id1_add As Label
    Friend WithEvents lb_accs_id2_add As Label
    Friend WithEvents cmb_accss_job_add As ComboBox
End Class
