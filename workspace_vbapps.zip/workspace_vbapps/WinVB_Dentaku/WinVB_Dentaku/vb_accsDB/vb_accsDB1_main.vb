﻿Imports System
Imports System.Data
Imports System.Data.Odbc

Public Class frm_accsDB
    '初期画面設定
    Private Sub frm_accsDB_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.ControlBox = Not Me.ControlBox

        main_dat_show()

    End Sub
    '閉じる
    Private Sub btn_accsclose_Click(sender As Object, e As EventArgs) Handles btn_accsclose.Click

        Me.Close()

    End Sub
    '登録画面開く
    Private Sub btn_accsadd_Click(sender As Object, e As EventArgs) Handles btn_accsadd.Click

        vb_accsDB2_add.Left = 100

        vb_accsDB2_add.Top = 200

        vb_accsDB2_add.StartPosition = FormStartPosition.Manual

        vb_accsDB2_add.ShowDialog()

    End Sub

    Private Sub dgv_accsDB_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_accsDB.CellContentClick

    End Sub

    '変更画面開く
    Private Sub btn_accschg_Click(sender As Object, e As EventArgs) Handles btn_accschg.Click

        If dgv_accsDB.CurrentCell.Value = "" Then

        Else

            vb_accsDB3_chg.Left = 100

            vb_accsDB3_chg.Top = 200

            vb_accsDB3_chg.StartPosition = FormStartPosition.Manual

            vb_accsDB3_chg.ShowDialog()

        End If
    End Sub

    '選択した行を削除
    Private Sub btn_accsdel_Click(sender As Object, e As EventArgs) Handles btn_accsdel.Click

        'アクセスへのOdbc接続
        Dim cn_del As OdbcConnection

        Dim dc_del As OdbcCommand

        Dim acfile_del As String = "D:\workspace_vbapps\vb_datfile\vb_db.accdb"

        Dim odbcdrv_del As String = "DSN=accessvb;DBQ=" & acfile_del & "; Uid=access; Pwd =access;"

        Dim strSQL_del As String

        '現在行の削除
        cn_del = New OdbcConnection(odbcdrv_del)

        cn_del.Open()

        'For Each selrow In dgv_accsDB.SelectedRows
        '
        '    MsgBox(selrow)
        '
        'Next
        For i = dgv_accsDB.Rows.Count - 2 To 1 Step -1

            If IsDBNull(dgv_accsDB.Rows(i).Cells(0).Value) = False Then

                If IsNothing(dgv_accsDB.Rows(i).Cells(0).Value) = False Then

                    If dgv_accsDB.Rows(i).Cells(0).Value Then

                        strSQL_del = "delete from Vb_dat_table where  [id] = '" & dgv_accsDB.Rows(i).Cells("id").Value & "';"

                        dc_del = New OdbcCommand(strSQL_del, cn_del)

                        dc_del.ExecuteNonQuery()

                        dc_del.Dispose()

                        dgv_accsDB.Rows.RemoveAt(i)

                    End If
                End If
            End If
        Next i

        cn_del.Close()

        'dgv_accsDB.Rows.Clear()

        main_dat_show()

    End Sub

    Public Sub main_dat_show()

        'アクセスへのOdbc接続
        Dim cn_datmain As OdbcConnection

        Dim da_datmain As OdbcDataAdapter

        '先頭列チェックボックス付き
        Dim ds_datmain As New DataTable
        ds_datmain.Columns.Add(New DataColumn("check", GetType(Boolean)))
        'dgv_accsDB.Columns.Insert(0, New DataGridViewCheckBoxColumn)

        'SQL読込設定
        Dim strSQL = "SELECT * FROM Vb_dat_table order by CINT(id) asc;"

        Dim acfile_datmain As String = "D:\workspace_vbapps\vb_datfile\vb_db.accdb"

        Dim odbcdrv_datmain As String = "DSN=accessvb;DBQ=" & acfile_datmain & "; Uid=access; Pwd =access;"

        cn_datmain = New OdbcConnection(odbcdrv_datmain)

        da_datmain = New OdbcDataAdapter(strSQL, cn_datmain)

        da_datmain.Fill(ds_datmain)

        dgv_accsDB.DataSource = ds_datmain

        cn_datmain.Close()

        dgv_accsDB.SelectionMode = DataGridViewSelectionMode.FullRowSelect
    End Sub

    Private Sub btn_DBtoCSV_Click(sender As Object, e As EventArgs) Handles btn_DBtoCSV.Click

        Dim dbtocsv_path As String = "D:\workspace_vbapps\vb_datfile\accssdbtocsvdat.csv"
        Dim dbtocsv_write As IO.StreamWriter
        Dim dbtocsv_write_str As String

        If dgv_accsDB.Rows.Count > 1 Then

            dbtocsv_write = New IO.StreamWriter(dbtocsv_path, False, System.Text.Encoding.GetEncoding("utf-8"))

            For i = 0 To dgv_accsDB.Rows.Count - 2

                For j = 1 To dgv_accsDB.Columns.Count - 1

                    dbtocsv_write_str = dbtocsv_write_str + dgv_accsDB.Rows(i).Cells(j).Value + ","

                Next j

                '最終行処理
                If i = dgv_accsDB.Rows.Count - 2 Then

                    dbtocsv_write_str = dbtocsv_write_str.TrimEnd(CType(",", Char))

                Else

                    dbtocsv_write_str = dbtocsv_write_str + vbNewLine

                End If
            Next i

            dbtocsv_write.Write(dbtocsv_write_str)

            dbtocsv_write.Close()

            MsgBox("書込み完了")

        End If
    End Sub
End Class