﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vb_accsDB3_chg
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lb_accs_id1_2 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btn_chg_close = New System.Windows.Forms.Button()
        Me.btn_accsDB_chg = New System.Windows.Forms.Button()
        Me.lb_accs_id2_chg = New System.Windows.Forms.Label()
        Me.tb_accs_name_chg = New System.Windows.Forms.TextBox()
        Me.tb_accs_sex_chg = New System.Windows.Forms.TextBox()
        Me.tb_accs_job_chg = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lb_accs_id1_2
        '
        Me.lb_accs_id1_2.AutoSize = True
        Me.lb_accs_id1_2.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.lb_accs_id1_2.Location = New System.Drawing.Point(41, 93)
        Me.lb_accs_id1_2.Name = "lb_accs_id1_2"
        Me.lb_accs_id1_2.Size = New System.Drawing.Size(27, 24)
        Me.lb_accs_id1_2.TabIndex = 0
        Me.lb_accs_id1_2.Text = "id"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.Label2.Location = New System.Drawing.Point(10, 126)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 24)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "名前"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.Label3.Location = New System.Drawing.Point(10, 163)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(58, 24)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "性別"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.Label4.Location = New System.Drawing.Point(10, 201)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 24)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "職業"
        '
        'btn_chg_close
        '
        Me.btn_chg_close.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_chg_close.Location = New System.Drawing.Point(158, 12)
        Me.btn_chg_close.Name = "btn_chg_close"
        Me.btn_chg_close.Size = New System.Drawing.Size(78, 60)
        Me.btn_chg_close.TabIndex = 1
        Me.btn_chg_close.Text = "閉じる"
        Me.btn_chg_close.UseVisualStyleBackColor = True
        '
        'btn_accsDB_chg
        '
        Me.btn_accsDB_chg.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_accsDB_chg.Location = New System.Drawing.Point(74, 12)
        Me.btn_accsDB_chg.Name = "btn_accsDB_chg"
        Me.btn_accsDB_chg.Size = New System.Drawing.Size(78, 60)
        Me.btn_accsDB_chg.TabIndex = 1
        Me.btn_accsDB_chg.Text = "変更"
        Me.btn_accsDB_chg.UseVisualStyleBackColor = True
        '
        'lb_accs_id2_chg
        '
        Me.lb_accs_id2_chg.AutoSize = True
        Me.lb_accs_id2_chg.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.lb_accs_id2_chg.Location = New System.Drawing.Point(74, 93)
        Me.lb_accs_id2_chg.Name = "lb_accs_id2_chg"
        Me.lb_accs_id2_chg.Size = New System.Drawing.Size(154, 24)
        Me.lb_accs_id2_chg.TabIndex = 2
        Me.lb_accs_id2_chg.Text = "　　　　　　　　　"
        '
        'tb_accs_name_chg
        '
        Me.tb_accs_name_chg.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.tb_accs_name_chg.Location = New System.Drawing.Point(74, 123)
        Me.tb_accs_name_chg.Name = "tb_accs_name_chg"
        Me.tb_accs_name_chg.Size = New System.Drawing.Size(162, 31)
        Me.tb_accs_name_chg.TabIndex = 3
        '
        'tb_accs_sex_chg
        '
        Me.tb_accs_sex_chg.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.tb_accs_sex_chg.Location = New System.Drawing.Point(74, 160)
        Me.tb_accs_sex_chg.Name = "tb_accs_sex_chg"
        Me.tb_accs_sex_chg.Size = New System.Drawing.Size(162, 31)
        Me.tb_accs_sex_chg.TabIndex = 3
        '
        'tb_accs_job_chg
        '
        Me.tb_accs_job_chg.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.tb_accs_job_chg.Location = New System.Drawing.Point(74, 198)
        Me.tb_accs_job_chg.Name = "tb_accs_job_chg"
        Me.tb_accs_job_chg.Size = New System.Drawing.Size(162, 31)
        Me.tb_accs_job_chg.TabIndex = 3
        '
        'vb_accsDB3_chg
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(256, 243)
        Me.Controls.Add(Me.tb_accs_job_chg)
        Me.Controls.Add(Me.tb_accs_sex_chg)
        Me.Controls.Add(Me.tb_accs_name_chg)
        Me.Controls.Add(Me.lb_accs_id2_chg)
        Me.Controls.Add(Me.btn_accsDB_chg)
        Me.Controls.Add(Me.btn_chg_close)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lb_accs_id1_2)
        Me.Name = "vb_accsDB3_chg"
        Me.Text = "変更画面"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lb_accs_id1_2 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents btn_chg_close As Button
    Friend WithEvents btn_accsDB_chg As Button
    Friend WithEvents lb_accs_id2_chg As Label
    Friend WithEvents tb_accs_name_chg As TextBox
    Friend WithEvents tb_accs_sex_chg As TextBox
    Friend WithEvents tb_accs_job_chg As TextBox
End Class
