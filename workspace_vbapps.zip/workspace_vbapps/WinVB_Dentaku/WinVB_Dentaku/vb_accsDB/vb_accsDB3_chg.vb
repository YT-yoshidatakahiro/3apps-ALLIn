﻿Imports System
Imports System.Data
Imports System.Data.Odbc

Public Class vb_accsDB3_chg

    '変更画面閉じる
    Private Sub btn_chg_close_Click(sender As Object, e As EventArgs) Handles btn_chg_close.Click

        '登録後メイン画面のグリッドビュー更新
        frm_accsDB.main_dat_show()

        Me.Close()

    End Sub

    Private Sub lb_accs_id2_add_Click(sender As Object, e As EventArgs) Handles lb_accs_id2_chg.Click

    End Sub

    '初期表示設定
    Private Sub vb_accsDB3_chg_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.ControlBox = Not Me.ControlBox

        '選択行の項目表示
        lb_accs_id2_chg.Text = frm_accsDB.dgv_accsDB.Rows(frm_accsDB.dgv_accsDB.CurrentCell.RowIndex).Cells(1).Value

        tb_accs_name_chg.Text = frm_accsDB.dgv_accsDB.Rows(frm_accsDB.dgv_accsDB.CurrentCell.RowIndex).Cells(2).Value

        tb_accs_sex_chg.Text = frm_accsDB.dgv_accsDB.Rows(frm_accsDB.dgv_accsDB.CurrentCell.RowIndex).Cells(3).Value

        tb_accs_job_chg.Text = frm_accsDB.dgv_accsDB.Rows(frm_accsDB.dgv_accsDB.CurrentCell.RowIndex).Cells(4).Value

    End Sub

    Private Sub btn_accsDB_chg_Click(sender As Object, e As EventArgs) Handles btn_accsDB_chg.Click
        'アクセスへのOdbc接続
        Dim cn_chg As OdbcConnection

        Dim dc_chg As OdbcCommand

        Dim acfile_chg As String = "D:\workspace_vbapps\vb_datfile\vb_db.accdb"

        Dim odbcdrv As String = "DSN=accessvb;DBQ=" & acfile_chg & "; Uid=access; Pwd =access;"

        Dim strSQL3 = "Update Vb_dat_table set [名前] = '" & tb_accs_name_chg.Text & "', [性別] = '" & tb_accs_sex_chg.Text & "', [職業] = '" & tb_accs_job_chg.Text & "' where [id] = '" & lb_accs_id2_chg.Text & "';"

        cn_chg = New OdbcConnection(odbcdrv)

        dc_chg = New OdbcCommand(strSQL3, cn_chg)

        cn_chg.Open()

        dc_chg.ExecuteNonQuery()

        dc_chg.Dispose()

        cn_chg.Close()

    End Sub
End Class