﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_accsDB
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btn_accsclose = New System.Windows.Forms.Button()
        Me.btn_accsadd = New System.Windows.Forms.Button()
        Me.btn_accschg = New System.Windows.Forms.Button()
        Me.btn_accsdel = New System.Windows.Forms.Button()
        Me.dgv_accsDB = New System.Windows.Forms.DataGridView()
        Me.btn_DBtoCSV = New System.Windows.Forms.Button()
        CType(Me.dgv_accsDB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_accsclose
        '
        Me.btn_accsclose.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_accsclose.Location = New System.Drawing.Point(497, 17)
        Me.btn_accsclose.Name = "btn_accsclose"
        Me.btn_accsclose.Size = New System.Drawing.Size(81, 45)
        Me.btn_accsclose.TabIndex = 0
        Me.btn_accsclose.Text = "閉じる"
        Me.btn_accsclose.UseVisualStyleBackColor = True
        '
        'btn_accsadd
        '
        Me.btn_accsadd.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_accsadd.Location = New System.Drawing.Point(12, 17)
        Me.btn_accsadd.Name = "btn_accsadd"
        Me.btn_accsadd.Size = New System.Drawing.Size(73, 45)
        Me.btn_accsadd.TabIndex = 0
        Me.btn_accsadd.Text = "登録"
        Me.btn_accsadd.UseVisualStyleBackColor = True
        '
        'btn_accschg
        '
        Me.btn_accschg.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_accschg.Location = New System.Drawing.Point(91, 17)
        Me.btn_accschg.Name = "btn_accschg"
        Me.btn_accschg.Size = New System.Drawing.Size(137, 45)
        Me.btn_accschg.TabIndex = 1
        Me.btn_accschg.Text = "登録変更"
        Me.btn_accschg.UseVisualStyleBackColor = True
        '
        'btn_accsdel
        '
        Me.btn_accsdel.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_accsdel.Location = New System.Drawing.Point(234, 17)
        Me.btn_accsdel.Name = "btn_accsdel"
        Me.btn_accsdel.Size = New System.Drawing.Size(137, 45)
        Me.btn_accsdel.TabIndex = 2
        Me.btn_accsdel.Text = "登録削除"
        Me.btn_accsdel.UseVisualStyleBackColor = True
        '
        'dgv_accsDB
        '
        Me.dgv_accsDB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_accsDB.Location = New System.Drawing.Point(12, 68)
        Me.dgv_accsDB.Name = "dgv_accsDB"
        Me.dgv_accsDB.RowTemplate.Height = 21
        Me.dgv_accsDB.Size = New System.Drawing.Size(566, 332)
        Me.dgv_accsDB.TabIndex = 3
        '
        'btn_DBtoCSV
        '
        Me.btn_DBtoCSV.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_DBtoCSV.Location = New System.Drawing.Point(377, 17)
        Me.btn_DBtoCSV.Name = "btn_DBtoCSV"
        Me.btn_DBtoCSV.Size = New System.Drawing.Size(114, 45)
        Me.btn_DBtoCSV.TabIndex = 0
        Me.btn_DBtoCSV.Text = "CSV出力"
        Me.btn_DBtoCSV.UseVisualStyleBackColor = True
        '
        'frm_accsDB
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(758, 416)
        Me.Controls.Add(Me.dgv_accsDB)
        Me.Controls.Add(Me.btn_accsdel)
        Me.Controls.Add(Me.btn_accschg)
        Me.Controls.Add(Me.btn_accsadd)
        Me.Controls.Add(Me.btn_DBtoCSV)
        Me.Controls.Add(Me.btn_accsclose)
        Me.Name = "frm_accsDB"
        Me.Text = "AccessDBメイン画面"
        CType(Me.dgv_accsDB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btn_accsclose As Button
    Friend WithEvents btn_accsadd As Button
    Friend WithEvents btn_accschg As Button
    Friend WithEvents btn_accsdel As Button
    Friend WithEvents dgv_accsDB As DataGridView
    Friend WithEvents btn_DBtoCSV As Button
End Class
