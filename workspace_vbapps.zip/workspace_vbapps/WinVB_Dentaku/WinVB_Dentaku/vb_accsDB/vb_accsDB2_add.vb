﻿Imports System
Imports System.Data
Imports System.Data.Odbc

Public Class vb_accsDB2_add

    '初期表示設定
    Private Sub vb_accsDB2_add_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.ControlBox = Not Me.ControlBox

        init_show_add()

    End Sub

    '登録ボタン
    Private Sub btn_accsDB_add_Click(sender As Object, e As EventArgs) Handles btn_accsDB_add.Click

        '登録実行
        register_add()

        '登録画面初期化
        init_show_add()

    End Sub

    '登録画面閉じるボタン
    Private Sub btn_add_close_Click(sender As Object, e As EventArgs) Handles btn_add_close.Click

        '登録後メイン画面のグリッドビュー更新
        frm_accsDB.main_dat_show()

        Me.Close()

    End Sub

    Private Sub cmb_accss_sex_add_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_accss_sex_add.SelectedIndexChanged, cmb_accss_job_add.SelectedIndexChanged

    End Sub


    '初期画面表示設定関数
    Public Sub init_show_add()

        tb_accs_name_add.Text = ""

        'アクセスへのOdbc接続
        Dim cn_add As OdbcConnection

        Dim da_add As OdbcDataAdapter

        Dim ds_add As New DataTable

        Dim dv_add As New DataView(ds_add)

        Dim strSQL_add = "SELECT * FROM Vb_dat_table;"

        Dim acfile_add As String = "D:\workspace_vbapps\vb_datfile\vb_db.accdb"

        Dim odbcdrv_add As String = "DSN=accessvb;DBQ=" & acfile_add & "; Uid=access; Pwd =access;"

        cn_add = New OdbcConnection(odbcdrv_add)

        da_add = New OdbcDataAdapter(strSQL_add, cn_add)

        da_add.Fill(ds_add)

        'id表示
        If ds_add.Rows.Count = 0 Then

            lb_accs_id2_add.Text = "1"

        Else

            lb_accs_id2_add.Text = ds_add.Rows(ds_add.Rows.Count - 1).Item("id") + 1

        End If

        '性別コンボボックス
        cmb_accss_sex_add.DataSource = dv_add.ToTable(True, "性別")

        cmb_accss_sex_add.DisplayMember = "性別"

        '職業コンボボックス
        cmb_accss_job_add.DataSource = dv_add.ToTable(True, "職業")

        cmb_accss_job_add.DisplayMember = "職業"

        cn_add.Close()

    End Sub

    Private Sub register_add()
        'アクセスへのOdbc接続
        Dim cn_add As OdbcConnection

        Dim dc_add As OdbcCommand

        Dim acfile_add As String = "D:\workspace_vbapps\vb_datfile\vb_db.accdb"

        Dim odbcdrv_add As String = "DSN=accessvb;DBQ=" & acfile_add & "; Uid=access; Pwd =access;"

        Dim strSQL_add = "insert into Vb_dat_table([id], [名前], [性別], [職業]) values('" & lb_accs_id2_add.Text & "','" & tb_accs_name_add.Text & "','" & cmb_accss_sex_add.Text & "','" & cmb_accss_job_add.Text & "');"


        cn_add = New OdbcConnection(odbcdrv_add)

        dc_add = New OdbcCommand(strSQL_add, cn_add)

        cn_add.Open()

        dc_add.ExecuteNonQuery()

        dc_add.Dispose()

        cn_add.Close()


    End Sub
End Class