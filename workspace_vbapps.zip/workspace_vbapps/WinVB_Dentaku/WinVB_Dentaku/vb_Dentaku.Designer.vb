﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Dentaku
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_four = New System.Windows.Forms.Button()
        Me.btn_five = New System.Windows.Forms.Button()
        Me.btn_six = New System.Windows.Forms.Button()
        Me.btn_minus = New System.Windows.Forms.Button()
        Me.btn_one = New System.Windows.Forms.Button()
        Me.btn_two = New System.Windows.Forms.Button()
        Me.btn_three = New System.Windows.Forms.Button()
        Me.btn_plus = New System.Windows.Forms.Button()
        Me.btn_zero = New System.Windows.Forms.Button()
        Me.btn_dot = New System.Windows.Forms.Button()
        Me.btn_eq = New System.Windows.Forms.Button()
        Me.btn_cancel = New System.Windows.Forms.Button()
        Me.btn_plusminus = New System.Windows.Forms.Button()
        Me.btn_percent = New System.Windows.Forms.Button()
        Me.btn_dev = New System.Windows.Forms.Button()
        Me.txtbx_dentaku = New System.Windows.Forms.TextBox()
        Me.btn_seven = New System.Windows.Forms.Button()
        Me.btn_eight = New System.Windows.Forms.Button()
        Me.btn_nine = New System.Windows.Forms.Button()
        Me.btn_product = New System.Windows.Forms.Button()
        Me.btn_Del = New System.Windows.Forms.Button()
        Me.btn_CloseDentaku = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_four
        '
        Me.btn_four.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_four.Location = New System.Drawing.Point(12, 305)
        Me.btn_four.Name = "btn_four"
        Me.btn_four.Size = New System.Drawing.Size(131, 77)
        Me.btn_four.TabIndex = 4
        Me.btn_four.Text = "4"
        Me.btn_four.UseVisualStyleBackColor = True
        '
        'btn_five
        '
        Me.btn_five.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_five.Location = New System.Drawing.Point(149, 305)
        Me.btn_five.Name = "btn_five"
        Me.btn_five.Size = New System.Drawing.Size(131, 77)
        Me.btn_five.TabIndex = 5
        Me.btn_five.Text = "5"
        Me.btn_five.UseVisualStyleBackColor = True
        '
        'btn_six
        '
        Me.btn_six.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_six.Location = New System.Drawing.Point(286, 305)
        Me.btn_six.Name = "btn_six"
        Me.btn_six.Size = New System.Drawing.Size(131, 77)
        Me.btn_six.TabIndex = 6
        Me.btn_six.Text = "6"
        Me.btn_six.UseVisualStyleBackColor = True
        '
        'btn_minus
        '
        Me.btn_minus.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_minus.Location = New System.Drawing.Point(423, 305)
        Me.btn_minus.Name = "btn_minus"
        Me.btn_minus.Size = New System.Drawing.Size(131, 77)
        Me.btn_minus.TabIndex = 16
        Me.btn_minus.Text = "-"
        Me.btn_minus.UseVisualStyleBackColor = True
        '
        'btn_one
        '
        Me.btn_one.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_one.Location = New System.Drawing.Point(12, 388)
        Me.btn_one.Name = "btn_one"
        Me.btn_one.Size = New System.Drawing.Size(131, 77)
        Me.btn_one.TabIndex = 1
        Me.btn_one.Text = "1"
        Me.btn_one.UseVisualStyleBackColor = True
        '
        'btn_two
        '
        Me.btn_two.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_two.Location = New System.Drawing.Point(149, 388)
        Me.btn_two.Name = "btn_two"
        Me.btn_two.Size = New System.Drawing.Size(131, 77)
        Me.btn_two.TabIndex = 2
        Me.btn_two.Text = "2"
        Me.btn_two.UseVisualStyleBackColor = True
        '
        'btn_three
        '
        Me.btn_three.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_three.Location = New System.Drawing.Point(286, 388)
        Me.btn_three.Name = "btn_three"
        Me.btn_three.Size = New System.Drawing.Size(131, 77)
        Me.btn_three.TabIndex = 3
        Me.btn_three.Text = "3"
        Me.btn_three.UseVisualStyleBackColor = True
        '
        'btn_plus
        '
        Me.btn_plus.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_plus.Location = New System.Drawing.Point(423, 388)
        Me.btn_plus.Name = "btn_plus"
        Me.btn_plus.Size = New System.Drawing.Size(131, 77)
        Me.btn_plus.TabIndex = 17
        Me.btn_plus.Text = "+"
        Me.btn_plus.UseVisualStyleBackColor = True
        '
        'btn_zero
        '
        Me.btn_zero.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_zero.Location = New System.Drawing.Point(12, 471)
        Me.btn_zero.Name = "btn_zero"
        Me.btn_zero.Size = New System.Drawing.Size(268, 77)
        Me.btn_zero.TabIndex = 0
        Me.btn_zero.Text = "0"
        Me.btn_zero.UseVisualStyleBackColor = True
        '
        'btn_dot
        '
        Me.btn_dot.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_dot.Location = New System.Drawing.Point(286, 471)
        Me.btn_dot.Name = "btn_dot"
        Me.btn_dot.Size = New System.Drawing.Size(131, 77)
        Me.btn_dot.TabIndex = 10
        Me.btn_dot.Text = "."
        Me.btn_dot.UseVisualStyleBackColor = True
        '
        'btn_eq
        '
        Me.btn_eq.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_eq.Location = New System.Drawing.Point(423, 471)
        Me.btn_eq.Name = "btn_eq"
        Me.btn_eq.Size = New System.Drawing.Size(131, 77)
        Me.btn_eq.TabIndex = 18
        Me.btn_eq.Text = "="
        Me.btn_eq.UseVisualStyleBackColor = True
        '
        'btn_cancel
        '
        Me.btn_cancel.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_cancel.Location = New System.Drawing.Point(12, 139)
        Me.btn_cancel.Name = "btn_cancel"
        Me.btn_cancel.Size = New System.Drawing.Size(131, 77)
        Me.btn_cancel.TabIndex = 11
        Me.btn_cancel.Text = "C"
        Me.btn_cancel.UseVisualStyleBackColor = True
        '
        'btn_plusminus
        '
        Me.btn_plusminus.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_plusminus.Location = New System.Drawing.Point(149, 139)
        Me.btn_plusminus.Name = "btn_plusminus"
        Me.btn_plusminus.Size = New System.Drawing.Size(131, 77)
        Me.btn_plusminus.TabIndex = 12
        Me.btn_plusminus.Text = "+/-"
        Me.btn_plusminus.UseVisualStyleBackColor = True
        '
        'btn_percent
        '
        Me.btn_percent.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_percent.Location = New System.Drawing.Point(286, 139)
        Me.btn_percent.Name = "btn_percent"
        Me.btn_percent.Size = New System.Drawing.Size(131, 77)
        Me.btn_percent.TabIndex = 13
        Me.btn_percent.Text = "%"
        Me.btn_percent.UseVisualStyleBackColor = True
        '
        'btn_dev
        '
        Me.btn_dev.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_dev.Location = New System.Drawing.Point(423, 139)
        Me.btn_dev.Name = "btn_dev"
        Me.btn_dev.Size = New System.Drawing.Size(131, 77)
        Me.btn_dev.TabIndex = 14
        Me.btn_dev.Text = "/"
        Me.btn_dev.UseVisualStyleBackColor = True
        '
        'txtbx_dentaku
        '
        Me.txtbx_dentaku.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.txtbx_dentaku.Location = New System.Drawing.Point(12, 102)
        Me.txtbx_dentaku.Name = "txtbx_dentaku"
        Me.txtbx_dentaku.Size = New System.Drawing.Size(542, 31)
        Me.txtbx_dentaku.TabIndex = 19
        Me.txtbx_dentaku.TabStop = False
        '
        'btn_seven
        '
        Me.btn_seven.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_seven.Location = New System.Drawing.Point(12, 222)
        Me.btn_seven.Name = "btn_seven"
        Me.btn_seven.Size = New System.Drawing.Size(131, 77)
        Me.btn_seven.TabIndex = 7
        Me.btn_seven.Text = "7"
        Me.btn_seven.UseVisualStyleBackColor = True
        '
        'btn_eight
        '
        Me.btn_eight.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_eight.Location = New System.Drawing.Point(149, 222)
        Me.btn_eight.Name = "btn_eight"
        Me.btn_eight.Size = New System.Drawing.Size(131, 77)
        Me.btn_eight.TabIndex = 8
        Me.btn_eight.Text = "8"
        Me.btn_eight.UseVisualStyleBackColor = True
        '
        'btn_nine
        '
        Me.btn_nine.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_nine.Location = New System.Drawing.Point(286, 222)
        Me.btn_nine.Name = "btn_nine"
        Me.btn_nine.Size = New System.Drawing.Size(131, 77)
        Me.btn_nine.TabIndex = 9
        Me.btn_nine.Text = "9"
        Me.btn_nine.UseVisualStyleBackColor = True
        '
        'btn_product
        '
        Me.btn_product.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_product.Location = New System.Drawing.Point(423, 222)
        Me.btn_product.Name = "btn_product"
        Me.btn_product.Size = New System.Drawing.Size(131, 77)
        Me.btn_product.TabIndex = 15
        Me.btn_product.Text = "*"
        Me.btn_product.UseVisualStyleBackColor = True
        '
        'btn_Del
        '
        Me.btn_Del.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_Del.Location = New System.Drawing.Point(149, 12)
        Me.btn_Del.Name = "btn_Del"
        Me.btn_Del.Size = New System.Drawing.Size(268, 77)
        Me.btn_Del.TabIndex = 20
        Me.btn_Del.Text = "一文字削除"
        Me.btn_Del.UseVisualStyleBackColor = True
        '
        'btn_CloseDentaku
        '
        Me.btn_CloseDentaku.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_CloseDentaku.Location = New System.Drawing.Point(423, 12)
        Me.btn_CloseDentaku.Name = "btn_CloseDentaku"
        Me.btn_CloseDentaku.Size = New System.Drawing.Size(131, 77)
        Me.btn_CloseDentaku.TabIndex = 21
        Me.btn_CloseDentaku.Text = "閉じる"
        Me.btn_CloseDentaku.UseVisualStyleBackColor = True
        '
        'frm_Dentaku
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(585, 625)
        Me.Controls.Add(Me.txtbx_dentaku)
        Me.Controls.Add(Me.btn_dev)
        Me.Controls.Add(Me.btn_eq)
        Me.Controls.Add(Me.btn_plus)
        Me.Controls.Add(Me.btn_product)
        Me.Controls.Add(Me.btn_minus)
        Me.Controls.Add(Me.btn_percent)
        Me.Controls.Add(Me.btn_dot)
        Me.Controls.Add(Me.btn_plusminus)
        Me.Controls.Add(Me.btn_three)
        Me.Controls.Add(Me.btn_CloseDentaku)
        Me.Controls.Add(Me.btn_Del)
        Me.Controls.Add(Me.btn_cancel)
        Me.Controls.Add(Me.btn_two)
        Me.Controls.Add(Me.btn_zero)
        Me.Controls.Add(Me.btn_nine)
        Me.Controls.Add(Me.btn_six)
        Me.Controls.Add(Me.btn_one)
        Me.Controls.Add(Me.btn_eight)
        Me.Controls.Add(Me.btn_five)
        Me.Controls.Add(Me.btn_seven)
        Me.Controls.Add(Me.btn_four)
        Me.Name = "frm_Dentaku"
        Me.Text = "電卓画面"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_four As Button
    Friend WithEvents btn_five As Button
    Friend WithEvents btn_six As Button
    Friend WithEvents btn_minus As Button
    Friend WithEvents btn_one As Button
    Friend WithEvents btn_two As Button
    Friend WithEvents btn_three As Button
    Friend WithEvents btn_plus As Button
    Friend WithEvents btn_zero As Button
    Friend WithEvents btn_dot As Button
    Friend WithEvents btn_eq As Button
    Friend WithEvents btn_cancel As Button
    Friend WithEvents btn_plusminus As Button
    Friend WithEvents btn_percent As Button
    Friend WithEvents btn_dev As Button
    Friend WithEvents txtbx_dentaku As TextBox
    Friend WithEvents btn_seven As Button
    Friend WithEvents btn_eight As Button
    Friend WithEvents btn_nine As Button
    Friend WithEvents btn_product As Button
    Friend WithEvents btn_Del As Button
    Friend WithEvents btn_CloseDentaku As Button
End Class
