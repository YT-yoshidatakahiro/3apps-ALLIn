﻿
Public Class frm_Dentaku

    'suutikakunouhensuu
    Dim aaa As String
    Dim bbb As String
    Dim ccc As Double


    '起動時の初期設定
    Private Sub frm_Dentaku_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.ControlBox = Not Me.ControlBox

        txtbx_dentaku.Text = ""
        aaa = 0
        bbb = 0
        ccc = 0
    End Sub

    '電卓終了
    Private Sub btn_CloseDentaku_Click(sender As Object, e As EventArgs) Handles btn_CloseDentaku.Click

        Me.Close()

    End Sub

    '表示画面のクリア
    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click

        txtbx_dentaku.Text = ""

        aaa = ""

    End Sub

    '+/-の符号をつける
    Private Sub btn_plusminus_Click(sender As Object, e As EventArgs) Handles btn_plusminus.Click

        If Strings.InStr(txtbx_dentaku.Text, "+") = 0 And Strings.InStr(txtbx_dentaku.Text, "-") = 0 Then

            txtbx_dentaku.Text = "+" + txtbx_dentaku.Text

        ElseIf Strings.Left(txtbx_dentaku.Text, 1) = "+" Then

            txtbx_dentaku.Text = Replace(txtbx_dentaku.Text, "+", "-")

        ElseIf Strings.Left(txtbx_dentaku.Text, 1) = "-" Then

            txtbx_dentaku.Text = Replace(txtbx_dentaku.Text, "-", "+")

        End If

    End Sub

    '最後尾の一文字削除
    Private Sub btn_Del_Click(sender As Object, e As EventArgs) Handles btn_Del.Click

        If txtbx_dentaku.Text.Length > 0 Then

            txtbx_dentaku.Text = txtbx_dentaku.Text.Remove(txtbx_dentaku.Text.Length - 1, 1)

            aaa = txtbx_dentaku.Text

        ElseIf txtbx_dentaku.Text.Length = 0 Then


        End If

    End Sub

    'パーセント表示
    Private Sub btn_percent_Click(sender As Object, e As EventArgs) Handles btn_percent.Click

        txtbx_dentaku.Text = txtbx_dentaku.Text / 100

    End Sub

    ''' <summary>
    ''' '数字表示
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>

    '0
    Private Sub btn_zero_Click(sender As Object, e As EventArgs) Handles btn_zero.Click

        aaa = aaa + "0"
        txtbx_dentaku.Text = aaa

    End Sub
    '1
    Private Sub btn_one_Click(sender As Object, e As EventArgs) Handles btn_one.Click

        aaa = aaa + "1"
        txtbx_dentaku.Text = Double.Parse(aaa)

    End Sub

    Private Sub btn_two_Click(sender As Object, e As EventArgs) Handles btn_two.Click

        aaa = aaa + "2"
        txtbx_dentaku.Text = Double.Parse(aaa)

    End Sub

    Private Sub btn_three_Click(sender As Object, e As EventArgs) Handles btn_three.Click

        aaa = aaa + "3"
        txtbx_dentaku.Text = Double.Parse(aaa)

    End Sub

    Private Sub btn_four_Click(sender As Object, e As EventArgs) Handles btn_four.Click

        aaa = aaa + "4"
        txtbx_dentaku.Text = Double.Parse(aaa)

    End Sub

    Private Sub btn_five_Click(sender As Object, e As EventArgs) Handles btn_five.Click

        aaa = aaa + "5"
        txtbx_dentaku.Text = Double.Parse(aaa)

    End Sub

    Private Sub btn_six_Click(sender As Object, e As EventArgs) Handles btn_six.Click

        aaa = aaa + "6"
        txtbx_dentaku.Text = Double.Parse(aaa)

    End Sub

    Private Sub btn_seven_Click(sender As Object, e As EventArgs) Handles btn_seven.Click

        aaa = aaa + "7"
        txtbx_dentaku.Text = Double.Parse(aaa)

    End Sub

    Private Sub btn_eight_Click(sender As Object, e As EventArgs) Handles btn_eight.Click

        aaa = aaa + "8"
        txtbx_dentaku.Text = Double.Parse(aaa)

    End Sub

    Private Sub btn_nine_Click(sender As Object, e As EventArgs) Handles btn_nine.Click

        aaa = aaa + "9"
        txtbx_dentaku.Text = Double.Parse(aaa)

    End Sub

    ''' <summary>
    ''' 四則演算
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btn_dev_Click(sender As Object, e As EventArgs) Handles btn_dev.Click

        txtbx_dentaku.Text = ""

        If bbb = 0 Then

            bbb = Double.Parse(aaa)

        Else

            bbb = Double.Parse(bbb) / Double.Parse(aaa)

        End If


        aaa = ""

        txtbx_dentaku.Text = bbb

    End Sub

    Private Sub btn_product_Click(sender As Object, e As EventArgs) Handles btn_product.Click

        txtbx_dentaku.Text = ""

        If bbb = 0 Then

            bbb = 1

        End If

        bbb = Double.Parse(bbb) * Double.Parse(aaa)

        aaa = ""

        txtbx_dentaku.Text = bbb

    End Sub

    Private Sub btn_minus_Click(sender As Object, e As EventArgs) Handles btn_minus.Click

        txtbx_dentaku.Text = ""

        bbb = Double.Parse(bbb) - Double.Parse(aaa)

        aaa = ""

        txtbx_dentaku.Text = bbb

    End Sub

    Private Sub btn_plus_Click(sender As Object, e As EventArgs) Handles btn_plus.Click

        txtbx_dentaku.Text = ""

        bbb = Double.Parse(bbb) + Double.Parse(aaa)

        aaa = ""

        txtbx_dentaku.Text = bbb

    End Sub

    Private Sub btn_eq_Click(sender As Object, e As EventArgs) Handles btn_eq.Click

        txtbx_dentaku.Text = Val(txtbx_dentaku.Text)

    End Sub

    'どっと
    Private Sub btn_dot_Click(sender As Object, e As EventArgs) Handles btn_dot.Click

        If InStr(txtbx_dentaku.Text, ".") <> 0 Then

        ElseIf Strings.Right(txtbx_dentaku.Text, 1) <> "." Then

            txtbx_dentaku.Text = txtbx_dentaku.Text + "."
            aaa = aaa + "."


        ElseIf Strings.Right(txtbx_dentaku.Text, 1) = "." Then

        End If

    End Sub

End Class
