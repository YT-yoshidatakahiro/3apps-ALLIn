﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vb_CSVinout
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_csvclose = New System.Windows.Forms.Button()
        Me.btn_csvread = New System.Windows.Forms.Button()
        Me.btn_csvwrite = New System.Windows.Forms.Button()
        Me.dgv_csvdat = New System.Windows.Forms.DataGridView()
        Me.btn_alldel = New System.Windows.Forms.Button()
        Me.btn_selecteddel = New System.Windows.Forms.Button()
        Me.btn_rowadd = New System.Windows.Forms.Button()
        Me.btn_selectdel = New System.Windows.Forms.Button()
        Me.dgv_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgv_name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgv_sex = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgv_job = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dgv_csvdat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_csvclose
        '
        Me.btn_csvclose.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_csvclose.Location = New System.Drawing.Point(633, 261)
        Me.btn_csvclose.Name = "btn_csvclose"
        Me.btn_csvclose.Size = New System.Drawing.Size(131, 77)
        Me.btn_csvclose.TabIndex = 6
        Me.btn_csvclose.Text = "閉じる"
        Me.btn_csvclose.UseVisualStyleBackColor = True
        '
        'btn_csvread
        '
        Me.btn_csvread.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_csvread.Location = New System.Drawing.Point(493, 12)
        Me.btn_csvread.Name = "btn_csvread"
        Me.btn_csvread.Size = New System.Drawing.Size(131, 77)
        Me.btn_csvread.TabIndex = 0
        Me.btn_csvread.Text = "csv読込み"
        Me.btn_csvread.UseVisualStyleBackColor = True
        '
        'btn_csvwrite
        '
        Me.btn_csvwrite.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_csvwrite.Location = New System.Drawing.Point(493, 95)
        Me.btn_csvwrite.Name = "btn_csvwrite"
        Me.btn_csvwrite.Size = New System.Drawing.Size(131, 77)
        Me.btn_csvwrite.TabIndex = 1
        Me.btn_csvwrite.Text = "csv書込み"
        Me.btn_csvwrite.UseVisualStyleBackColor = True
        '
        'dgv_csvdat
        '
        Me.dgv_csvdat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_csvdat.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.dgv_id, Me.dgv_name, Me.dgv_sex, Me.dgv_job})
        Me.dgv_csvdat.Location = New System.Drawing.Point(12, 12)
        Me.dgv_csvdat.Name = "dgv_csvdat"
        Me.dgv_csvdat.RowTemplate.Height = 21
        Me.dgv_csvdat.Size = New System.Drawing.Size(475, 326)
        Me.dgv_csvdat.TabIndex = 3
        Me.dgv_csvdat.TabStop = False
        '
        'btn_alldel
        '
        Me.btn_alldel.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_alldel.Location = New System.Drawing.Point(630, 12)
        Me.btn_alldel.Name = "btn_alldel"
        Me.btn_alldel.Size = New System.Drawing.Size(131, 77)
        Me.btn_alldel.TabIndex = 2
        Me.btn_alldel.Text = "全削除"
        Me.btn_alldel.UseVisualStyleBackColor = True
        '
        'btn_selecteddel
        '
        Me.btn_selecteddel.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_selecteddel.Location = New System.Drawing.Point(630, 178)
        Me.btn_selecteddel.Name = "btn_selecteddel"
        Me.btn_selecteddel.Size = New System.Drawing.Size(131, 77)
        Me.btn_selecteddel.TabIndex = 4
        Me.btn_selecteddel.Text = "現在行" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "削　除"
        Me.btn_selecteddel.UseVisualStyleBackColor = True
        '
        'btn_rowadd
        '
        Me.btn_rowadd.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_rowadd.Location = New System.Drawing.Point(493, 178)
        Me.btn_rowadd.Name = "btn_rowadd"
        Me.btn_rowadd.Size = New System.Drawing.Size(131, 77)
        Me.btn_rowadd.TabIndex = 3
        Me.btn_rowadd.Text = "行追加"
        Me.btn_rowadd.UseVisualStyleBackColor = True
        '
        'btn_selectdel
        '
        Me.btn_selectdel.Font = New System.Drawing.Font("MS UI Gothic", 18.0!)
        Me.btn_selectdel.Location = New System.Drawing.Point(630, 95)
        Me.btn_selectdel.Name = "btn_selectdel"
        Me.btn_selectdel.Size = New System.Drawing.Size(131, 77)
        Me.btn_selectdel.TabIndex = 6
        Me.btn_selectdel.Text = "選択行" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "削　除"
        Me.btn_selectdel.UseVisualStyleBackColor = True
        '
        'dgv_id
        '
        Me.dgv_id.HeaderText = "id"
        Me.dgv_id.Name = "dgv_id"
        Me.dgv_id.Width = 70
        '
        'dgv_name
        '
        Me.dgv_name.HeaderText = "名前"
        Me.dgv_name.Name = "dgv_name"
        '
        'dgv_sex
        '
        Me.dgv_sex.HeaderText = "性別"
        Me.dgv_sex.Name = "dgv_sex"
        '
        'dgv_job
        '
        Me.dgv_job.HeaderText = "職業"
        Me.dgv_job.Name = "dgv_job"
        '
        'vb_CSVinout
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(776, 351)
        Me.Controls.Add(Me.dgv_csvdat)
        Me.Controls.Add(Me.btn_csvwrite)
        Me.Controls.Add(Me.btn_csvread)
        Me.Controls.Add(Me.btn_selecteddel)
        Me.Controls.Add(Me.btn_selectdel)
        Me.Controls.Add(Me.btn_rowadd)
        Me.Controls.Add(Me.btn_alldel)
        Me.Controls.Add(Me.btn_csvclose)
        Me.Name = "vb_CSVinout"
        Me.Text = "CSVファイル読み書き"
        CType(Me.dgv_csvdat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btn_csvclose As Button
    Friend WithEvents btn_csvread As Button
    Friend WithEvents btn_csvwrite As Button
    Friend WithEvents dgv_csvdat As DataGridView
    Friend WithEvents btn_alldel As Button
    Friend WithEvents btn_selecteddel As Button
    Friend WithEvents btn_rowadd As Button
    Friend WithEvents btn_selectdel As Button
    Friend WithEvents dgv_id As DataGridViewTextBoxColumn
    Friend WithEvents dgv_name As DataGridViewTextBoxColumn
    Friend WithEvents dgv_sex As DataGridViewTextBoxColumn
    Friend WithEvents dgv_job As DataGridViewTextBoxColumn
End Class
